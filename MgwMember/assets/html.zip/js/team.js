var team;

function load() {
	getTeam();

	$(".staff-pic").height($(".pic-box").width());
	$(".staff-complaints ul li img").height($(".staff-complaints ul li img").width());
}

function getTeam() {
	var ajax_obj = {
		type: 'client.getteam', 
		userid: user.UserID, 
		serial: user.serial, 
		sid: user.sid
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			team = data.items;

			for (var i = 0; i < team.length; i++) {
				var staff = team[i];

				var html = '<div class="staff-box">';
					html += '<div class="staff-top" onclick="checkStaff(' + staff.id + ')">';
					html += '<div class="pic-box">';
					html += '<img class="staff-pic" data-original="' + staff.img + '" />';
					html += '</div>';
					html += '<div class="staff-info">';
					html += '<div class="info-msg">工号：' + staff.code + '</div>';
					html += '<div class="info-msg">等级：' + staff.name + '</div>';
					html += '<a href="javascript:void(0);" class="btn" onclick="tapZan(event, ' + i + ')"><div class="staff-zan">' + staff.zan + '</div></a>';
					html += '</div>';
					html += '</div>';
					html += '<div class="staff-desc">技术特点：' + staff.tech + '</div>';
					html += '</div>';

				$(html).appendTo($(".main"));
			};

			$('.pic-box').height($('.pic-box').width());
			$("img").lazyload();
		} else {
			$.fn.yuertips({
				msg: data.msg, 
				allowClose: false, 
				pageurl: "index.html", 
				pagename: "首页"
			});
		}
	});
}

function checkStaff(id) {
	location.href = "per.html?sid=" + id;
}

function tapZan(event, index) {
	var eventSource = $(event.target);
	if (event.target.tagName != "A") {
		eventSource = $(event.target).parent("a");
	}

	eventSource.addClass("active");	
	var timer = setInterval(function(){
		eventSource.removeClass("active");
		clearInterval(timer);
	}, 500);

	var ajax_obj = {
		type: 'client.staffzaned', 
		userid: user.UserID, 
		serial: user.serial, 
		sid: team[index].id
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			team[index].zan += 1;

			$(event.target).text(team[index].zan);
		} else {
			$.fn.yuertips({
				msg: data.msg
			});
		}
	});

	event.stopPropagation();
}