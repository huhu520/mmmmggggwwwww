﻿function load() {
	/*$(".expect").css({
		width: constVariable.clientWidth, 
		height: constVariable.clientHeight*/
	});
}