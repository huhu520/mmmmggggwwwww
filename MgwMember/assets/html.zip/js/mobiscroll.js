; (function($) {
    // 预约人数
    var appoint_persons = null;
    // 预约日期
    var appoint_date = null;
    // 预约时间
    var appoint_time = null;

    /*属性写在构造函数中*/
    function mobIScroll(el, opts, callback) {
        var self = this;
        self.source = el;
        self.type = opts.type;
        self.data = [];
        self.unit = opts.unit;
        self.defaultValue = "";
        self.touchObj = self.source.find(opts.touchObj);
        self.moveObj = self.source.find(opts.moveObj);
        self.interval = 1;
        self.moveDistance = 0;

        if (self.touchObj.length == 0 || self.moveObj.length == 0) {
            return;
        }
        
        //执行
        self.init(callback);
        self.bind(callback);
    }
    /*方法写在原型中*/
    mobIScroll.prototype = {
        /*初始化*/
        init: function(callback) {
            var self = this;
            self.config(callback);
            self.move();
        },
        /*配置*/
        config: function(callback) {
            var self = this;

            // 清空容器
            self.moveObj.empty();
            self.data = [];
            self.interval = 1;

            if (self.type == "num") { // 人数栏目
                // 设置默认值
                self.defaultValue = 1;

                // 添加数据项
                for (var i = 1; i <= 9; i++) {
                    self.moveObj.append('<div class="info-item">' + i + self.unit + '</div>');
                    self.data.push(i);
                };
            } else if (self.type == "date") { // 日期栏目
                var today = self.defaultValue && self.defaultValue != (new Date()).toDay() ? new Date(self.defaultValue) : new Date();
                
                // 设置默认日期为当天
                self.defaultValue = today.toDay();

                // 添加数据项
                for (var i = 0; i <= 7; i++) {
                    self.moveObj.append('<div class="info-item">' + today.DateAdd("d", i).toDay() + '</div>');
                    self.data.push(today.DateAdd("d", i).toDay());
                };
            } else if (self.type == "time") { // 事件栏目
                var today = (new Date(appoint_date.defaultValue)).toDay() != (new Date()).toDay() ? new Date(appoint_date.defaultValue) : new Date();

                var hour = 0;
                if ((new Date(appoint_date.defaultValue)).toDay() == (new Date()).toDay()) {
                    hour = (today.getMinutes() >= 30 ? today.getHours() + 1 : today.getHours());
                }

                if (hour == 24) {
                    hour = 0;

                    appoint_date.defaultValue = (new Date(appoint_date.defaultValue).DateAdd('d', 1)).toDay();
                    appoint_date.init();
                }

                for (var i = 0; i <= 23 - hour; i++) {
                    self.moveObj.append('<div class="info-item">' + (hour + i) + ":30" + '</div>');
                    self.data.push((hour + i) + ":30"); 

                    if (self.defaultValue == (hour + i) + ":30") {
                        self.interval = 1 - i;
                    }
                };

                if (self.defaultValue == "") {
                    self.defaultValue = hour + ":30";
                }
            } else { // 未知类型
                return;
            }

            self.moveDistance = self.moveObj.find(".info-item").height();

            if (self.type == "time") {
                if (callback) {
                    callback({
                        number: appoint_persons.defaultValue, 
                        date: appoint_date.defaultValue,
                        time: self.defaultValue
                    });
                }
            }
        },
        /*移动*/
        move: function(mPos) {
            var self = this;

            if (!mPos)
                mPos = 0;
            
            self.moveObj.css({ '-webkit-transform': 'translate3d(0,' + (self.interval * self.moveDistance + mPos) + 'px,0)' });
        },
        /*touch事件*/
        bind: function(callback) {
            var self = this;
            var startX, startY, endY;
            function touchStart(event) {
                if (!event.touches.length) return;

                var touch = event.touches[0];
                startX = touch.pageX;
                startY = touch.pageY;
            }
            function touchMove(event) {
                if (!event.touches.length) return;
                var touch = event.touches[0],
                    x = touch.pageX - startX,
                    y = touch.pageY - startY;

                //阻止网页默认动作（即网页滑动）
                event.preventDefault();
                //这里是为了手指一定是横向滑动的,原理是计算X位置的偏移要比Y的偏移大
                if (Math.abs(y) > Math.abs(x)) {
                    //向上滑动
                    if (y < 0) {
                        self.move(y);
                    }
                    //向下滑动
                    else {
                        self.move(y);
                    }

                    endY = y;
                }
            }
            function touchEnd(event) {
                if (!endY) 
                    return;

                var dis = parseInt(endY / self.moveDistance), 
                    mod = endY % self.moveDistance; 
                
                if (dis > 0) {
                    if (mod >= self.moveDistance/3) 
                        dis+=1;
                } else if (dis < 0) {
                    if (Math.abs(mod) >= self.moveDistance/3) 
                        dis-=1;
                } else {
                    if (mod > 0 && Math.abs(mod) >= self.moveDistance/3) 
                        dis+=1;
                    else if (mod < 0 && Math.abs(mod) >= self.moveDistance/3)
                        dis-=1;
                }
                
                self.interval+=dis;
                if (self.interval > 1) 
                    self.interval = 1;
                if (self.interval < -self.data.length + 2) 
                    self.interval = (-self.data.length + 2);
                
                self.move();

                if (self.type == "date" && self.defaultValue != self.data[Math.abs(self.interval - 1)]) {
                    self.defaultValue = self.data[Math.abs(self.interval - 1)];
                    appoint_time.init();
                }

                self.defaultValue = self.data[Math.abs(self.interval - 1)];

                if (callback) {
                    callback({
                        number: appoint_persons.defaultValue, 
                        date: appoint_date.defaultValue,
                        time: appoint_time.defaultValue
                    });
                }

                endY = 0;
            }
            //手机是高级浏览器，不必做addEventListener的兼容
            self.touchObj[0].addEventListener("touchstart", touchStart, false);
            self.touchObj[0].addEventListener("touchmove", touchMove, false);
            self.touchObj[0].addEventListener("touchend", touchEnd, false);
        }
    };
    //插件
    $.fn.mobIScroll = function(options, callback) {
        var opts = $.extend({},$.fn.mobIScroll.defaults, options);

        if (!opts.touchObj || !opts.moveObj)  {
            return;
        }

        this.each(function() {
            //new构造函数对象
            var person_opts = opts;
            person_opts.type = "num";
            person_opts.unit = "人";
            appoint_persons = new mobIScroll($(this).find(".l .info-box"), person_opts, callback);

            var date_opts = opts;
            date_opts.type = "date";
            date_opts.unit = "";
            appoint_date = new mobIScroll($(this).find(".m .info-box"), date_opts, callback);

            var time_opts = opts;
            time_opts.type = "time";
            time_opts.unit = "";
            appoint_time = new mobIScroll($(this).find(".r .info-box"), time_opts, callback);
        });
    };
    /*定义默认值*/
    $.fn.mobIScroll.defaults = {
        // 滚动触发对象
        touchObj: ".info-shandow",
        // 发生移动对象
        moveObj: ".info-list"
    };
})(jQuery)