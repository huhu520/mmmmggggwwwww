
(function ($) {
    $.fn.lazyload = function (options) {
        var defaults = {
            tagName: "img"
        };
        var opts = $.extend({}, defaults, options);

        var elements = $(this);

        var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        var clientHeight = document.documentElement.clientHeight;
        var imgs = new Array(elements.length);
        
        $("body").bind("scroll", function(){
            scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            
            lazyload();
        });
        
        function lazyload() {
            elements.each(function(){
                var obj = $(this);
                var offsetTop = obj.offset().top;
                
                if (!imgs[elements.index(obj)] && offsetTop < scrollTop + clientHeight) {
                    if (opts.tagName == "img") { 
                        var timer = setInterval(function(){
                            obj.attr("src", obj.attr("data-original")).bind("load", function(){
                                obj.siblings(".loading-cover").remove();
                            }).removeAttr("data-original");
                        }, 500);
                    }

                    imgs[elements.index(obj)] = true;
                }
            });
        }

        function init() {
            elements.each(function(){
                var self = $(this);
                
                if (self.attr("data-original") && self.siblings(".loading-cover").length == 0) {
                    self.parent().css("position", "relative");
                    self.parent().append('<div class="loading-cover"></div>'); 
                }
            });
        }

        init();
        lazyload();
        
        return this;
    };
})(jQuery);