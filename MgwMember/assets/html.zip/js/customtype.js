var customtype;

function load() {
	init();

	//$(".img-box").height(constVariable.clientWidth*3/7);
}

function init() {
	var tid = GetQueryString("tid");
	var tname = GetQueryString("tname");
	$("#tname").text(tname);

	var ajax_obj = { 
		type: "client.getcustomtypeitems", 
		userid: user.UserID, 
		serial: user.serial, 
		tid: tid 
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			customtype = data.items;

			for (var i = 0; i < customtype.length; i++) {
				var type = customtype[i];

				var html = '<div class="item-box">';
					html += '<div class="itme" onclick="checkedItem(\'' + type.id + '\')">';
					html += '<div class="img-box">';
					html += '<img data-original="' + type.imgurl + '" width="100%" alt="" />';
					html += '</div>';
					html += '<div class="title">' + type.title + '</div>';
					html += '<div class="content">' + type.content + '</div>';
					html += '</div>';
					html += '</div>';

				$(html).appendTo($(".main"));
			};

			$(".img-box").height(constVariable.clientWidth*3/7);
			$("img").lazyload();			
		}
	});
}

function checkedItem(id) {
	location.href = "customitem.html?iid=" + id;
}