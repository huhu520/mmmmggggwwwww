var opinion = {};

function load() {
	opinion.bid = GetQueryString("bid");
	opinion.consumeTime = GetQueryString("time");
	opinion.counter = [1, 2, 3, 4, 5];

	if (!opinion.bid) {
		$.fn.yuertips({
			msg: "错误的单据编号", 
			pageurl: "index.html", 
			pagename: "首页"
		});
		return;
	}

	$("#consumeTime").text(opinion.consumeTime + "分");

	var ajax_obj = { 
		type: "client.getunevaldetails", 
		userid: user.UserID, 
		serial: user.serial, 
		bid: opinion.bid 
	}
	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			for (var i = 0; i < data.items.length; i++) {
				if (!data.items[i].score) {
					data.items[i].score = 0;
				} 
				var html = "";
				if (data.items[i].type == 0) {
					html += '<div class="type">';
				} else {
					html += '<div class="product">';
				}

	            html += '<div class="sort">';
              	html += '<p>' + data.items[i].name + '</p>';
              	html += '<div class="sort-r">';
                html += '<ul class="rating">';
                for (var k = 0; k < opinion.counter.length; k++) {
                	html += '<li><a href="javascript:void(0);" ms-attr-title="' + opinion.counter[k] + ' Star" onclick="onelevel(event, ' + i + ',' + opinion.counter[k] + ')">' + opinion.counter[k] + '</a></li>';
                };
                html += '</ul>';
	            html += '</div>';
	            html += '</div>';

				for (var j = 0; j < data.items[i].staff.length; j++) {
					if (data.items[i].type == 0) {
						data.items[i].staff[j].type = 2;
					} else {
						data.items[i].staff[j].type = 3;
					}

					html += '<div class="man bdr-grey-bottom">';
		            html += '<div class="man-left">';
	                html += '<dl>';
                  	html += '<dt><img src="" data-original="' + data.items[i].staff[j].img + '" onerror="this.src=\'http://file.mgw.cc/avatar-100.png\'" /></dt>';
	               	html += '<dd>' + data.items[i].staff[j].name + '<br />';
                    html += '工号：' + data.items[i].staff[j].code + '</dd>';
	                html += '</dl>';
	              	html += '</div>';
	              	html += '<div class="sort-r">';
	                html += '<ul class="rating">';
	                for (var k = 0; k < opinion.counter.length; k++) {
	                	html += '<li><a href="javascript:void(0);" title="' + opinion.counter[k] + ' Star" onclick="twolevel(event, ' + i + ',' + j + ',' + opinion.counter[k] + ')">' + opinion.counter[k] + '</a></li>';
	                };
	                html += '</ul>';
		            html += '</div>';
		            html += '</div>';

					if (!data.items[i].staff[j].score) {
						data.items[i].staff[j].score = 0;
					}
				};

				html += "</div>";

				$(html).appendTo($('.info'));
			};

			opinion.data = data.items;
		}
	});
}

function onelevel(event, index, score) {
	opinion.data[index].score = score;

	var ul = $(event.target).parent("li").parent('ul');
	ul.find("a").each(function(){
		if (ul.find("a").index($(this)) <= score - 1) {
			$(this).addClass("selected").removeClass("active");
		} else {
			$(this).addClass("active").removeClass("selected");
		}
	});
}

function twolevel(event, index1, index2, score) {
	opinion.data[index1].staff[index2].score = score;

	var ul = $(event.target).parent("li").parent('ul');
	ul.find("a").each(function(){
		if (ul.find("a").index($(this)) <= score - 1) {
			$(this).addClass("selected").removeClass("active");
		} else {
			$(this).addClass("active").removeClass("selected");
		}
	});
}

function submit(){
	opinion.content = $("#content").val();

	// 提交所需参数
	var ajax_date = {
		type: "client.evaluate", 
		userid: user.UserID, 
		serial: user.serial, 
		bid: opinion.bid, 
		mid: user.memberid, 
		groupid: user.groupid, 
		uid: user.uid, 
		content: opinion.content, 
		paras: ''
	};
	var eval_score = [];

	// 获取评分数据
	for (var i = 0; i < opinion.data.length; i++) {
		var pro = opinion.data[i];
		if (pro.score > 0) {
			eval_score.push(pro.proid + "," + pro.type + "," + pro.score);
		}

		for (var j = 0; j < pro.staff.length; j++) {
			var staff = pro.staff[j];
			if (staff.score > 0) {
				eval_score.push(staff.staffid + "," + staff.type + "," + staff.score);
			}
		};
	};

	// 判断评分
	if (eval_score.length == 0) {
		$.fn.yuertips({
			msg: "请您选择至少一项进行评分。"
		});
		return;
	}

	// 判断评价内容
	if (ajax_date.content == '') {
		$.fn.yuertips({
			msg: "请填写您的评价内容。"
		});
		return;
	}

	ajax_date.paras = eval_score.join(";");

	$.ajax({
		url: constVariable.interfaceName, 
		type: "POST", 
		dataType: "jsonp", 
		jsonp: "callback", 
		jsonpCallBack: "success_jsonpCallBack", 
		data: ajax_date, 
		success: function(data){
			if (data.flag == 0) {
				transferTo('index.html', '');
			} else {
				$.fn.yuertips({
					msg: "评价失败。"
				});
			}
		}, 
		error: function(){
			$.fn.yuertips({
				msg: "网络异常。"
			});
		}
	});
}