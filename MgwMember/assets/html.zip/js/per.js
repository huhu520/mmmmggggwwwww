var staff;

function load() {
	getStaff();
}

function getStaff() {
	var staffid = GetQueryString("sid");
	
	var ajax_obj = {
		type: 'client.getstaff', 
		userid: user.UserID, 
		serial: user.serial, 
		sid: staffid
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			staff = data.item;

			$("#staffimg").attr("data-original", staff.img);
			$(".staff-info:eq(0)").text("工号：" + staff.code);
			$(".staff-info:eq(1)").text("等级：" + staff.name);
			$("#staffzan").text(staff.zan);
			$(".per-tec").text("技术特点：" + staff.tech);
			$(".per-desc").append(staff.desc);

			if (staff.staff) {
				$("a", ".per-orde").attr("href", "orde.html?staff=" + staff.staff + "&name=" + urlEncode(staff.name));
				$(".per-orde").hide();
			}

			$("img").lazyload();
		} else {
			$.fn.yuertips({
				msg: data.msg, 
				allowClose: false, 
				pageurl: 'team.html', 
				pagename: '团队展示'
			});
		}
	});
}

function staffZan(event) {
	var eventSource = $(event.target);
	if (event.target.tagName != "A") {
		eventSource = $(event.target).parent("a");
	}

	eventSource.addClass("active");	
	var timer = setInterval(function(){
		eventSource.removeClass("active");
		clearInterval(timer);
	}, 500);

	var ajax_obj = {
		type: 'client.staffzaned', 
		userid: user.UserID, 
		serial: user.serial, 
		sid: staff.id
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			staff.zan += 1;

			$("#staffzan").text(staff.zan);
		} else {
			$.fn.yuertips({
				msg: data.msg
			});
		}
	});

	event.stopPropagation();
}