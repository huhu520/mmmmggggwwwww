function load() {
	init();

	$(".search-btn").bind("click", function(){
		search();
	});
}

var bindshop = [];
var selectedIndex = -1;

function init() {
	if (bindshop.length > 0) {
		$(".data-none").hide();
		$(".data ul").html("");

		for (var i = 0; i < bindshop.length; i++) {
			var shop = bindshop[i];

			var html = '<li onclick="selectItem(' + i + ')">' + shop.name + '</li>';
			$(html).appendTo($(".data ul"));
		};
		$(".data").show();
	} else {
		bindshop = [];
		selectedIndex = -1;
		$(".data").hide();
		$(".data-none").show();
	}
}

function search() {
	if ($("#text").val() == "") {
		$.fn.yuertips({
			msg: "请输入搜索关键字"
		});
		return;
	}

	var screen_obj = $.fn.dataloading();

	var ajax_obj = { 
		type: "client.searchclient", 
		userid: user.UserID, 
		serial: user.serial, 
		name: $("#text").val() 
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			bindshop = data.items;
			
			init();
		} else {
			$.fn.yuertips({
				msg: data.msg
			});
		}

		screen_obj.destory();
	});
}

function selectItem(index) {
	selectedIndex = index;
	$(".data ul li:eq(" + selectedIndex + ")").addClass("data-selected").siblings().removeClass("data-selected");
}

function attentionShop() {
	if (selectedIndex == -1) {
		$.fn.yuertips({
			msg: '请选择绑定店铺'
		});
		return;
	}

	var _screen_obj = $.fn.dataloading({
		msg: "数据处理中"
	});

	var shop = bindshop[selectedIndex];
	var ajax_obj = { 
		type: "client.attentionshop", 
		userid: user.UserID, 
		serial: user.serial, 
		groupid: shop.groupid, 
		uid: shop.uid, 
		sid: shop.sid 
	}

	ajax(ajax_obj, function (data) {
		_screen_obj.destory();
		
		if (data.flag == 0) {
			setClientInfo(shop.groupid, shop.uid, shop.sid);

			$.fn.yuertips({
				msg: '绑定成功', 
				allowClose: false, 
				pageurl: 'index.html', 
				pagename: '首页'
			});
		} else {
			$.fn.yuertips({
				msg: data.msg
			});
		}
	});
}