var eval_flag = false;

function load(){
	get_ads();

	loadSupplierInfo();

	getCustomType();

	loadUnionList();
	
	$(".banner").height(constVariable.clientWidth/2);

	// 关联店铺图片加载完毕后计算文本高度
	/*var img1 = document.getElementById("shopimg");
	img1.onload = function() {
		//$(".shop-info p").height($(".shop-img").height()/3).css("line-height", $(".shop-img").height()/3 + "px");

		$(".evaluate").css({ 
			left: $(".shop-func ul li:eq(1)").offset().left + $(".shop-func ul li:eq(1)").width() - 5 + "px", 
			top: $(".shop-func ul li:eq(1)").offset().top - 3 - $(".header").outerHeight() + "px" 
		});

		if (eval_flag) {
			$(".evaluate").show();
		}
	}*/
}

// 获取广告列表
function get_ads() {
	var ajax_obj = { 
		type: "member.getcomad", 
		userid: user.UserID, 
		serial: user.serial 
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			if ($(".banner ul").length == 0) {
				$(".banner").append("<ul></ul>");
			}

			for (var i = 0; i < data.items.length; i++) {
				$(".banner ul").append('<li onclick="toAds(\'' + data.items[i].id + '\')"><img data-original="' + data.items[i].img + '" alt="" /></li>');
			}

			$(".banner").touchSlide();
			$("img").lazyload();
		}
	});
}

// 获取关联商家信息
function loadSupplierInfo(){
	var ajax_obj = { 
		type: "wzreposity.supplierinfo", 
		userid: user.UserID, 
		serial: user.serial, 
		sid: user.sid, 
		posx: 0, 
		posy: 0 
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			var supplier = data.items[0];

			/*$("#mySupplier").bind("click", function(){
				toSupplier(user.sid);
			});*/
			$("#shopimg").attr("data-original", supplier.image);
			
			$("p:eq(0)", "#bindsupplier .shop-info").html(supplier.sname);
			$("p:eq(1)", "#bindsupplier .shop-info").html(supplier.Tel);
			$("p:eq(2)", "#bindsupplier .shop-info").html(supplier.saddr);

			if (!supplier.gu && supplier.gu != "") {
				$("#consult").bind("click", function(){
					toConsulter(supplier.gu);
				});
			} else {
				$("#consult").addClass("dis").bind("click", function(){
					$.fn.yuertips({ 
						msg: "抱歉，商家尚未设置咨询顾问。"
					});
				});
			}

			if (user.memberid == "") {
				$("#opinion").addClass("dis").bind("click", function(){
					$.fn.yuertips({ 
						msg: "绑定关联店铺的消费卡后，才能评价店铺消费。"
					});
				});
			} else {
				getUnEval();
			}
			
			$("img").lazyload();
		}
	});
}

// 获取会员待评价消费
function getUnEval() {
	var ajax_obj = { 
		type: "client.getuneval", 
		userid: user.UserID, 
		serial: user.serial, 
		mid: user.memberid, 
		groupid: user.groupid, 
		uid: user.uid 
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			if (data.item["bid"] == "") {
				$("#opinion").addClass("dis").bind("click", function(){
					$.fn.yuertips({ 
						msg: "没有待评价的店铺消费。"
					});
				});
			} else {
				$("#opinion").bind("click", function(){
					transferTo("opinion.html?bid=" + data.item["bid"] + "&time=" + data.item["time"], '');
				});
				eval_flag = true;
			}
		}
	});
}

// 获取店铺业务类型
function getCustomType() {
	var ajax_obj = { 
		type: "client.getcustomtype", 
		userid: user.UserID, 
		serial: user.serial, 
		sid: user.sid 
	}

	ajax(ajax_obj,  function (data) {
		if (data.flag == 0) {

			data.items.push({tid: "", tname: "团队展示", imgurl: "../images/bg_16.png", content: "知名美发团队成员"});

			var html = "";
			for (var i = 0; i < data.items.length; i++) {
				html += '<div class="type-item" onclick="redirectTo(\'';
				if (data.items[i].tid && data.items[i].tid != "") {
					html += 'customtype.html?tid=' + data.items[i].tid + 
					'&tname=' + urlEncode(data.items[i].tname);
				} else {
					html += "team.html";
				}
				html += '\')">';
				html += '<div class="item-img" style="background-image: url(' + data.items[i].imgurl + ');">';
				html += '</div>';
				html += '<div class="item-name color-' + (i + 1) + '">';
				html += data.items[i].tname;
				html += '</div>';
				html += '<div class="item-content">';
				html += data.items[i].content;
				html += '</div>';
				html += '</div>';
			};

			$(".type-list").append(html);
			//$("img").lazyload();
		}
	});
}

// 获取我的联盟商家信息
function loadUnionList(){
	var ajax_obj = { 
		type: "client.getunionsupplier", 
		userid: 
		user.UserID, 
		serial: user.serial, 
		sid: user.sid 
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			if (!data.items) {
				$(".ali-none").hide();
				return;
			}

			var html = "";
			for (var i = 0; i < data.items.length; i++) {
				var supplier = data.items[i];

				html += '<div class="ali-area" onclick="toSupplier(\'' + supplier.sid + '\')">';
				html += '<div class="ali-img" style="background-image:url(' + supplier.imgurl + ');">';
				//html += '<img data-original="' + supplier.imgurl + '" width="100%" alt="" />';
				html += '</div>';
				html += '<div class="ali-info name">' + supplier.sname + '</div>';
				html += '<div class="ali-info">' + supplier.tel + '</div>';
				html += '<div class="ali-info">' + supplier.addr + '</div>';
				html += '</div>';

			};
			
			$(".ali-list").append(html);

			$("img").lazyload();
		}
	});
}