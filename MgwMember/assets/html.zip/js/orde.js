// 预约信息对象
var appointment = {};

function load(){
	appointment.FCAppoint_CName = user.MemberName;
	appointment.FCAppoint_Phone = user.Telephone;
	appointment.FCAppoint_ManNum = (user.Gender == "男" ? 1 : 0);
	appointment.FCAppoint_WNum = (user.Gender == "男" ? 0 : 1);
	appointment.Matter_Selected = 0;
	appointment.FStaffID = GetQueryString("staff");
	appointment.staffName = GetQueryString("name");
	if (!appointment.FStaffID) {
		$(".input tr:eq(2)").hide();
	}

	init();
}

function init() {
	// 初始化预约联系人和联系电话
	$("#appiontName").val(appointment.FCAppoint_CName);
	$("#appointTel").val(appointment.FCAppoint_Phone);

	var ajax_obj = { 
		type: "appointment.appointmatter", 
		groupid: user.groupid 
	};

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			appointment.FCAppoint_Matter = data.items;

			// 插入预约事项DOM元素
			if (data.flag == 0) {
				for (var i = 0; i < appointment.FCAppoint_Matter.length; i++) {
					$(".list ul").append('<li class="matter-bg-' + ((i % 8) + 1) + '" onclick="checkType(' + i + ')"><a href="javascript:void(0);">' + 
						appointment.FCAppoint_Matter[i].AppointMatter_Name + '</a><b></b></li>');
				}
			}
			
			// 初始第一个预约事项选中
			$(".list ul li:eq(0)").click();
		} else {
			$.fn.yuertips({
				msg: "获取预约事项信息失败。", 
				allowClose: false, 
				pageurl: "index.html", 
				pagename: "首页"
			});
			return;
		}
	});
	
	$(".number").mobIScroll({}, function (result) {
		if (appointment.FCAppoint_ManNum > 0) {
			appointment.FCAppoint_ManNum = result.number;
		} else if (appointment.FCAppoint_WNum > 0) {
			appointment.FCAppoint_WNum = result.number;
		}

		appointment.FCAppoint_Date = result.date + " " + result.time + ":00";
	});
}

function checkType(index) {
	appointment.Matter_Selected = index;
	
	// 选中点击的预约事项
	$(".list .selected").removeClass("selected");
	$("b", ".list ul li:eq(" + index + ")").addClass("selected");
}

function submit() {
	appointment.FCAppoint_CName = $("#appiontName").val();
	appointment.FCAppoint_Phone = $("#appointTel").val();
	appointment.FCAppoint_Text = $("#appiontText").val();

	var ajax_obj = {
		type: "appointment.add", 
		mid: user.memberid, 
		mname: appointment.FCAppoint_CName, 
		tel: appointment.FCAppoint_Phone, 
		groupid: user.groupid, 
		uid: user.uid, 
		man: appointment.FCAppoint_ManNum, 
		woman: appointment.FCAppoint_WNum, 
		date: appointment.FCAppoint_Date, 
		matter: appointment.FCAppoint_Matter[appointment.Matter_Selected].AppointMatter_ID, 
		staff: appointment.FStaffID, 
		msg: appointment.FCAppoint_Text
	}

	if (!ajax_obj.mname) {
		$.fn.yuertips({
			msg: "请填写预约联系人。"
		});
	}
	if (!ajax_obj.tel) {
		$.fn.yuertips({
			msg: "请填写预约联系电话。"
		});
	}

	ajax(ajax_obj, function (data) {
		if (data.flag == 0) {
			transferTo('index.html', '');
		} else {
			$.fn.yuertips({
				msg: data.msg
			});
		}
	});
}