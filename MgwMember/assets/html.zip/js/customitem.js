var customitem;

function load() {
	init();
}

function init() {
	var itemid = GetQueryString("iid");

	var ajax_obj = { 
		type: "client.getcustomitem", 
		userid: user.UserID, 
		serial: user.serial, 
		itemid: itemid 
	}

	ajax(ajax_obj, function(data) {
		if (data.flag == 0) {
			customitem = data.item;

			$("#title").text(customitem.title);
			$(".img-box img").attr("data-original", customitem.imgurl);
			$(".content").text(customitem.content);
			$(".desc").html(customitem.desc);
			
			if (customitem.pid <= 0) {
				$(".buy-now").hide();
			} else {
				$(".buy-now").bind("click", function() {
					buyInSupplier(user.sid, customitem.pid);
				});
			}

			$(".img-box").height(constVariable.clientWidth*3/7);
			$("img").lazyload();
		}
	});
}