;(function($){
	$.fn.rating = function (options, callback) {
		var defaults = { 
			activeObj: "li", 
			classOjb: "a", 
			selectedClass: "selected", 
			activeClass: "active"
		};

		var opts = $.extend({}, defaults, options);
		var self = this;

		var init = function (callback) {
			$(opts.activeObj, self).each(function(){
				$(this).bind("click", function () {
					var $index = $(opts.activeObj, self).index($(this));
					$(opts.classOjb, self).removeClass("selected").removeClass("active");

					for (var i = 0; i < $(opts.classOjb, self).length; i++) {
						var $obj = $(opts.classOjb + ":eq(" + i + ")", self);
						if (i <= $index) {
							$obj.addClass("selected");
						} else {
							$obj.addClass("active");
						}
					};

					if (callback && typeof callback === "function") {
						callback($index + 1);
					}
				});
			});
		}

		init(callback);
	}
})(jQuery);